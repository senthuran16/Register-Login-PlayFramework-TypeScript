package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import views.User;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by USER on 2017-03-03.
 */
public class UserController extends Controller {

    // hashmap functions as the database
    // key : username
    // value : particular user object
    Map<String, User> db = new HashMap<>();


    /**
     * finds the user with the given username and return the user object
     * @param username
     * @return found user object
     */
    public User findUser(String username){

        // find user from the hashmap, who is containing the given username as the key
        User user = db.get(username);

        return user;

    }


    /**
     * returns validation status, validated with provided username and password
     * @param username
     * @param password
     * @return validation boolean status
     */
    public boolean validateUser(String username, String password){

        // find the user with the given username
        User user = findUser(username);

        // return status of username + password combination
        return (password.equals(user.getPassword()));

    }


    /**
     * gets the complete user object after validating
     * @param username

     * @return user object as Result
     * * Rendered as String to the browser, but compatible as json object (code is implemented but not used)
     */
    public Result findUserByUsername(String username, String password) {

        // json object which will have the object, parsed into
        JsonNode json;

        // string to be returned at end
        String ret;

        // user validation
        if(validateUser(username,password)){

            // user validation successfull

            // get the found user
            User foundUser = findUser(username);

            // convert the found user as json object
            json = Json.toJson(foundUser);

            // string message to show the user details
            ret = "Login Success!\n\nHello "+foundUser.getName()+"!\n\nUsername :"+foundUser.getUsername() +"\nEmail : "+foundUser.getEmail();

        }else{

            // user validation not successful

            // string message to show error
            ret = "Login failure!\nPlease check your credentials";

            // convert the found user as json object
            json = Json.toJson(null);

        }

        // return the string
        return ok(ret);

    }


    /**
     * signs up a user by adding the user details into the hashmap : db
     * @param username
     * @param password
     * @param name
     * @param email
     * @return created instance of user
     */
    public Result saveUser(String username, String password, String name, String email) {

        // the signed up user object
        User user = new User();
        // set user details
        user.setUsername(username);
        user.setPassword(password);
        user.setName(name);
        user.setEmail(email);

        // put the user object into the hashmap
        db.put(username,user);

        // user creation success message
        return created("User "+user.getUsername()+" has been successfully updated!\n\nName : "+user.getName()+"\nUsername :"+user.getUsername() +"\nEmail : "+user.getEmail()+"\nPassword : "+user.getPassword());
    }

}
