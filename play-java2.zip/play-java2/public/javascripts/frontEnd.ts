/**
 * Created by USER on 2017-03-12.
 */

/**
 * Created by USER on 2017-03-10.
 */

/**
 * returns whether element passed through parameter has a value - and acceptable
 * @param elementId : id of the element to be validated
 * @param elementPrompt : used in error message
 * @returns {boolean} : true when element is acceptable
 */
function acceptable(elementId,elementPrompt){

    // get the value of passed element
    let val =  (<HTMLInputElement>document.getElementById(elementId)).value;

    // check for element's value
    if(val == ""){
        // value is empty
        // error message
        alert("Please fill out the "+elementPrompt+" field");
        return false;
    }

    return true;

}

/**
 * returns validity of username on condition : No space should be there
 * @param elementId
 * @returns {boolean} validity of username
 */
function usernameValidity(elementId){
    // get username from field
    let username = (<HTMLInputElement>document.getElementById(elementId)).value;

    // check each character of username
    for(let i=0; i<username.length ; i++){
        // if username contains space
        if(username.charAt(i)==" "){
            // invalid username
            // error
            alert("Username should not contain any spaces.");
            return false;
        }
    }

    return true;
}

/**
 * returns validity of email
 * @param elementId
 * @returns {boolean} : email validity
 */
function emailValidity(elementId){

    // get the value of the email field
    let email = (<HTMLInputElement>document.getElementById(elementId)).value;

    // counter to count @ symbol
    var countAt = 0;

    // check each character of the email address
    for(let i=0 ; i<email.length ; i++){

        // if any character is @
        if(email.charAt(i)=='@'){
            countAt++;
        }else {
            // character other than @

            // space is not allowed. All other characters are allowed
            if (email.charAt(i) == ' ') {
                // space found
                // error
                alert("Email should should not contain space. Please check your email");
                return false;
            }

        }

    }


    // if number of @ symbol is not exactly 1
    if (countAt!=1){

        // not exactly one @ symbol is available
        // error
        alert ("Email should contain exactly one '@' symbol.");
        return false;

    }


    // reaching here means exactly one @ symbol available, and no space detected

    // email address will be like : someone@something.com
    // split 'someone' and 'something.com' as two array elements
    var emailComponents = email.split("@");

    // to count dots
    var dotCounter=0;

    // check only 'something.com' for at least one dot : that is necessary
    // there may be more than one dot : eg : iit.ac.lk

    // count dots in second element of the split array
    for(let i=0 ; i<emailComponents[1].length ; i++){

        // count dots
        if(emailComponents[1].charAt(i)=="."){
            dotCounter++;
        }

    }

    // check whether at least one dot is there
    if(dotCounter < 1){

        // no dots are there
        alert("Invalid email address. Please check the domain name");
        return false;

    }

    // reaching this points means, email address is fine

    return true;


}

/**
 * returns whether the password is strong enough
 * a strong password is :
 * at least one number & at least one letter
 * at least 8 characters in total
 * @param elementId
 */
function strongPassword(elementId){

    // read the password
    let password = (<HTMLInputElement>document.getElementById(elementId)).value;

    // counters to count total characters, letters and numbers
    var totalChars = 0;
    var alphabetics = 0;
    var numerics = 0;

    // count each letter in password
    for(var i=0 ; i<password.length ; i++){

        if(password.charCodeAt(i)>=48 && password.charCodeAt(i)<=57){

            // number
            numerics++;

        }else{

            // alphabetic (special characters are also counted here)
            alphabetics++;
        }

        // total characters
        totalChars++;

    }

    if(totalChars>=8){
        // total length is more than 8 characters
        if(numerics>0){
            // at least one number
            if(alphabetics>0){
                // at least one letter

                // strong password
                return true;

            }else{
                // no letters
                // error
                alert("Password not strong enough! Please include at least one alphabetic character");
                return false;
            }

        }else{
            // no numbers
            // error
            alert("Password not strong enough! Please include at least one numeric character");
            return false;

        }

    }else{
        // total characters is not more than 8 characters
        // error
        alert("Weak password! Please include at least 8 characters");
        return false;
    }



}

/**
 * performs signup with necessary validations
 */
function signup(){

    // check for validity of every field
    if( acceptable("fname","Full Name") && acceptable("uname","Username") && usernameValidity("uname") && acceptable("email","Email") && (emailValidity("email")) && acceptable("password","Password") && strongPassword("password")) {

        // every validation is passed

        // get values from input fields
        let fname = (<HTMLInputElement>document.getElementById("fname")).value;
        let uname = (<HTMLInputElement>document.getElementById("uname")).value;
        let email = (<HTMLInputElement>document.getElementById("email")).value;
        let password = (<HTMLInputElement>document.getElementById("password")).value;

        // redirect
        window.location.href = "http://localhost:9000/overnightAssignment1/signup/" + uname + "/" + password + "/" + fname + "/" + email;

    }

    // else : respective errors will be given out


}

/**
 * performs login
 */
function login(){

    let username = (<HTMLInputElement>document.getElementById("unameLogin")).value;
    let password = (<HTMLInputElement>document.getElementById("passwordLogin")).value;

    // redirect
    window.location.href = "http://localhost:9000/overnightAssignment1/login/"+username+"/"+password;
}

/**
 * displays initial contents
 */
function welcome(){
    document.getElementById("signupDiv").style.display="none";
    document.getElementById("loginDiv").style.display="none";
}

/**
 * shows the signup form
 */
function showSignup(){
    document.getElementById("signupDiv").style.display="block";
    document.getElementById("loginDiv").style.display="none";
    document.getElementById("welcomeDiv").style.display="none";
}

/**
 * shows the login form
 */
function showLogin(){
    document.getElementById("loginDiv").style.display="block";
    document.getElementById("signupDiv").style.display="none";
    document.getElementById("welcomeDiv").style.display="none";
}





